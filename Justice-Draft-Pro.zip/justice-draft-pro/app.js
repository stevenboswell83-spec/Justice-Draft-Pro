// Justice Draft Pro - Guided drafting aid
// Not legal advice. Structured around public UK best practice.

let selectedType = null;
let formData = {};

const typeConfigs = {
  'pip-mr': {
    title: 'PIP Mandatory Reconsideration',
    fields: [
      { id: 'name', label: 'Your full name', type: 'text', required: true },
      { id: 'ni', label: 'National Insurance number', type: 'text', required: true },
      { id: 'decisionDate', label: 'Date of decision letter', type: 'text', placeholder: 'e.g. 15 March 2026' },
      { id: 'activities', label: 'Which activities do you disagree with? (list them)', type: 'textarea', placeholder: 'e.g. Preparing food, Washing and bathing, Planning and following journeys' },
      { id: 'mainPoints', label: 'For each activity: what actually happens, how often, and why it is not reliable (safely / acceptable standard / repeatedly / reasonable time)', type: 'textarea', placeholder: 'Be specific. Example: "On most days I cannot prepare a meal safely because..."' },
      { id: 'evidence', label: 'Evidence you are enclosing (list documents)', type: 'textarea', placeholder: 'e.g. GP letter dated..., symptom diary, carer statement' },
      { id: 'address', label: 'Your address (optional)', type: 'textarea' }
    ]
  },
  'pip-appeal': {
    title: 'PIP Appeal Support Letter',
    fields: [
      { id: 'name', label: 'Your full name', type: 'text', required: true },
      { id: 'ni', label: 'National Insurance number', type: 'text' },
      { id: 'mrDate', label: 'Date of Mandatory Reconsideration Notice', type: 'text' },
      { id: 'mainPoints', label: 'Key points you want the tribunal to understand (facts, impact, reliability issues)', type: 'textarea' },
      { id: 'evidence', label: 'Evidence you will rely on', type: 'textarea' },
      { id: 'whatYouWant', label: 'What outcome are you seeking?', type: 'textarea' }
    ]
  },
  'adjustment': {
    title: 'Reasonable Adjustment Request',
    fields: [
      { id: 'name', label: 'Your full name', type: 'text', required: true },
      { id: 'recipient', label: 'Who are you writing to? (manager / HR / organisation)', type: 'text' },
      { id: 'conditionImpact', label: 'How does your condition affect you at work / in this context? (factual)', type: 'textarea' },
      { id: 'adjustment', label: 'What specific adjustment are you requesting?', type: 'textarea' },
      { id: 'whyHelp', label: 'How will this help you do your role / access the service?', type: 'textarea' },
      { id: 'evidence', label: 'Any supporting evidence (optional)', type: 'textarea' }
    ]
  },
  'grievance': {
    title: 'Workplace Grievance',
    fields: [
      { id: 'name', label: 'Your full name', type: 'text', required: true },
      { id: 'recipient', label: 'Who are you writing to?', type: 'text' },
      { id: 'timeline', label: 'What happened? (chronological facts, dates where possible)', type: 'textarea' },
      { id: 'impact', label: 'How has this affected you?', type: 'textarea' },
      { id: 'resolution', label: 'What outcome are you seeking?', type: 'textarea' },
      { id: 'evidence', label: 'Evidence you have or will provide', type: 'textarea' }
    ]
  },
  'dwp-letter': {
    title: 'DWP Formal Letter',
    fields: [
      { id: 'name', label: 'Your full name', type: 'text', required: true },
      { id: 'ni', label: 'National Insurance / reference number', type: 'text' },
      { id: 'subject', label: 'Subject of the letter', type: 'text' },
      { id: 'facts', label: 'Key facts and what has happened', type: 'textarea' },
      { id: 'request', label: 'What are you asking for?', type: 'textarea' },
      { id: 'evidence', label: 'Evidence enclosed', type: 'textarea' }
    ]
  },
  'general': {
    title: 'General Formal Letter',
    fields: [
      { id: 'name', label: 'Your full name', type: 'text', required: true },
      { id: 'recipient', label: 'Recipient', type: 'text' },
      { id: 'subject', label: 'Subject', type: 'text' },
      { id: 'purpose', label: 'Purpose of the letter and key points', type: 'textarea' },
      { id: 'request', label: 'What do you want to happen?', type: 'textarea' }
    ]
  }
};

document.addEventListener('DOMContentLoaded', () => {
  // Type selection
  document.querySelectorAll('.type-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      selectedType = btn.dataset.type;
      showForm(selectedType);
    });
  });

  document.getElementById('back-btn').addEventListener('click', () => {
    document.getElementById('form-screen').classList.add('hidden');
    document.getElementById('type-screen').classList.remove('hidden');
  });

  document.getElementById('generate-btn').addEventListener('click', generateLetter);
  document.getElementById('copy-btn').addEventListener('click', copyLetter);
  document.getElementById('new-btn').addEventListener('click', () => {
    document.getElementById('output-screen').classList.add('hidden');
    document.getElementById('type-screen').classList.remove('hidden');
    formData = {};
  });

  // Register service worker for PWA
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/service-worker.js').catch(() => {});
  }
});

function showForm(type) {
  const config = typeConfigs[type];
  const container = document.getElementById('form-content');
  container.innerHTML = `<h2 style="margin-bottom:1rem">${config.title}</h2>`;

  config.fields.forEach(field => {
    const div = document.createElement('div');
    div.innerHTML = `
      <label for="${field.id}">${field.label}${field.required ? ' *' : ''}</label>
      ${field.type === 'textarea'
        ? `<textarea id="${field.id}" placeholder="${field.placeholder || ''}"></textarea>`
        : `<input type="${field.type}" id="${field.id}" placeholder="${field.placeholder || ''}">`
      }
    `;
    container.appendChild(div);
  });

  document.getElementById('type-screen').classList.add('hidden');
  document.getElementById('form-screen').classList.remove('hidden');
  document.getElementById('output-screen').classList.add('hidden');
}

function getFormData() {
  const data = {};
  const config = typeConfigs[selectedType];
  config.fields.forEach(f => {
    const el = document.getElementById(f.id);
    data[f.id] = el ? el.value.trim() : '';
  });
  return data;
}

function generateLetter() {
  formData = getFormData();
  const letter = buildLetter(selectedType, formData);
  document.getElementById('letter-output').textContent = letter;
  document.getElementById('form-screen').classList.add('hidden');
  document.getElementById('output-screen').classList.remove('hidden');
}

function buildLetter(type, d) {
  const today = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  const name = d.name || '[Your Name]';

  let letter = '';

  if (type === 'pip-mr') {
    letter = `${name}
${d.address || '[Your Address]'}
${d.ni ? 'National Insurance number: ' + d.ni : ''}

${today}

Personal Independence Payment
[Address from your decision letter]

Dear Sir or Madam,

Request for Mandatory Reconsideration

I am requesting a Mandatory Reconsideration of the PIP decision dated ${d.decisionDate || '[decision date]'}.
My National Insurance number is ${d.ni || '[NI number]'}.

I disagree with the scoring on the following activities:

${d.activities || '[List the activities you disagree with]'}

For each activity I set out below what actually happens on most days, why the activity cannot be completed reliably (safely, to an acceptable standard, repeatedly, and in a reasonable time under Regulation 4(2A) of the Social Security (PIP) Regulations 2013), and the evidence that supports this.

${d.mainPoints || '[Insert your specific points for each activity here. Be factual and quantify frequency where possible.]'}

Evidence enclosed:
${d.evidence || '[List your enclosures]'}

I ask that a different decision maker reconsider the decision in light of this letter and the enclosed evidence. Please send me the Mandatory Reconsideration Notice in writing.

Yours faithfully,

${name}`;
  }
  else if (type === 'adjustment') {
    letter = `${today}

Dear ${d.recipient || 'Manager / HR'},

Reasonable Adjustment Request under the Equality Act 2010

I am writing to request a reasonable adjustment.

${d.conditionImpact || '[Describe factually how your condition affects you in this context.]'}

The adjustment I am requesting is:
${d.adjustment || '[State the specific adjustment clearly.]'}

This would help because:
${d.whyHelp || '[Explain how it would reduce the disadvantage.]'}

${d.evidence ? 'I enclose the following supporting information:\n' + d.evidence : ''}

I would be grateful if we could discuss this and receive a written response.

Yours sincerely,

${name}`;
  }
  else if (type === 'grievance') {
    letter = `${today}

Dear ${d.recipient || 'Manager / HR'},

Formal Grievance

I am raising a formal grievance regarding the following matters.

What happened:
${d.timeline || '[Set out the facts in chronological order, with dates where possible.]'}

Impact:
${d.impact || '[Describe the impact factually.]'}

I am seeking the following outcome:
${d.resolution || '[State clearly what you want to happen.]'}

${d.evidence ? 'I can provide the following evidence:\n' + d.evidence : ''}

I would like this grievance to be investigated in accordance with the organisation’s procedure and to receive a written outcome.

Yours sincerely,

${name}`;
  }
  else if (type === 'dwp-letter') {
    letter = `${name}
${d.ni ? 'Reference / NI: ' + d.ni : ''}

${today}

Dear Sir or Madam,

${d.subject || 'Formal Correspondence'}

${d.facts || '[Set out the relevant facts clearly and calmly.]'}

I am requesting:
${d.request || '[State what you are asking for.]'}

${d.evidence ? 'Evidence enclosed:\n' + d.evidence : ''}

Please confirm receipt and respond in writing.

Yours faithfully,

${name}`;
  }
  else {
    // General or PIP appeal fallback
    letter = `${today}

Dear ${d.recipient || 'Sir or Madam'},

${d.subject || 'Formal Letter'}

${d.purpose || d.mainPoints || '[Set out your points clearly and factually.]'}

${d.request || d.whatYouWant ? '\nI am requesting:\n' + (d.request || d.whatYouWant) : ''}

${d.evidence ? '\nEvidence / supporting information:\n' + d.evidence : ''}

Yours faithfully,

${name}`;
  }

  return letter;
}

function copyLetter() {
  const text = document.getElementById('letter-output').textContent;
  navigator.clipboard.writeText(text).then(() => {
    const btn = document.getElementById('copy-btn');
    const original = btn.textContent;
    btn.textContent = 'Copied!';
    setTimeout(() => btn.textContent = original, 2000);
  }).catch(() => {
    alert('Please select the text and copy it manually.');
  });
}
