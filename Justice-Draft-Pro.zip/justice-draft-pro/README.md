# Justice Draft Pro

Guided drafting aid for UK benefits, disability and employment letters.

**Important: This is not legal advice.** Always check time limits, official guidance, and seek free advice (Citizens Advice, etc.) where appropriate.

## How to install on Android

1. Download and unzip this folder.
2. Upload the folder to a free host so it is served over HTTPS. Easiest options:
   - Go to https://app.netlify.com/drop and drag the unzipped folder onto the page.
   - Or use GitHub Pages, Vercel, or any static host.
3. Open the link that is generated in Chrome on your Android phone.
4. Tap the menu (three dots) → **Add to Home screen** or **Install app**.

Once installed it will open like a normal app.

## How to use

1. Choose the type of letter.
2. Fill in the guided fields with your facts (be specific and factual).
3. Generate the draft.
4. Copy it, review carefully, edit anything that is not accurate, then send.

The drafts follow public best-practice structures (PIP reliability criteria, calm factual tone, clear requests, Equality Act style for adjustments). They are starting points only.

## Note

This tool does not contain any proprietary training data from Justice Writer Pro or any other commercial product. It is an independent drafting aid built from publicly available guidance.
